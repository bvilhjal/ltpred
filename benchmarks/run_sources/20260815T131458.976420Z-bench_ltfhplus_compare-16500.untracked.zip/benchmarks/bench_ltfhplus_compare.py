"""Locked comparison of ltpred against public R LTFHPlus.

LTFHPlus is Gibbs-only. This script feeds the *same* simulated families and
bounds to three estimators:

  * LTFHPlus::estimate_liability (Rcpp Gibbs, default n_sim=1e5, burn_in=1000)
  * ltpred Gibbs with the same tol / n_sim / burn_in
  * ltpred Pearson-Aitken (no mixture)

It reports score agreement (correlation, RMSE, max abs) and wall-clock.
That is a software comparison, not the intra-package PA-vs-Gibbs grid in
``bench_scaling.py``. LTFHPlus parallelises families with ``future``; ltpred
Gibbs uses Numba ``prange``. The script therefore records both worker counts
and does not treat a fold-speed as a universal constant.

Requires R with LTFHPlus installed::

    install.packages("LTFHPlus")
    # or remotes::install_github("EmilMiP/LTFHPlus")

    python benchmarks/run_benchmark.py bench_ltfhplus_compare.py

Exits 2 (skip) if R or LTFHPlus is missing, so CI stays green without them.
"""

from __future__ import annotations

import argparse
import csv
import os
import shutil
import subprocess
import sys
import tempfile
import time

import numpy as np

from _common import estimate, simulate_families

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
R_HELPER = os.path.join(HERE, "ltfhplus_compare.R")

try:
    from numba import get_num_threads
except ImportError:  # pragma: no cover
    def get_num_threads():
        return 1

H2 = 0.5
PREV = 0.05
FAM_VEC = ["m", "f", "s1"]
N_FAM = 200
REPS = 3
TOL = 0.01
N_SIM = 100_000
BURN_IN = 1000
SEED = 20260815


def _check_ltfhplus():
    rscript = shutil.which("Rscript")
    if rscript is None:
        return None, "Rscript not on PATH"
    probe = (
        "if (!requireNamespace('LTFHPlus', quietly=TRUE)) "
        "quit(status=2); "
        "cat(as.character(packageVersion('LTFHPlus')))"
    )
    proc = subprocess.run(
        [rscript, "-e", probe], capture_output=True, text=True)
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "LTFHPlus not installed").strip()
        return None, err.splitlines()[-1] if err else "LTFHPlus not installed"
    return proc.stdout.strip(), None


def families_to_tbl(families, path):
    """Write the LTFHPlus .tbl (fam_ID, indiv_ID, role, lower, upper)."""
    with open(path, "w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=("fam_ID", "indiv_ID", "role", "lower", "upper"),
            lineterminator="\n")
        writer.writeheader()
        for fam in families:
            fid = str(fam.fam_id)
            for member in fam.members:
                if member.role == "g":
                    continue
                pid = (str(member.pid) if member.pid is not None
                       else f"{fid}_{member.role}")
                writer.writerow(dict(
                    fam_ID=fid, indiv_ID=pid, role=member.role,
                    lower=_fmt_bound(member.lower),
                    upper=_fmt_bound(member.upper),
                ))


def _fmt_bound(value):
    value = float(value)
    if np.isneginf(value):
        return "-Inf"
    if np.isposinf(value):
        return "Inf"
    return repr(value)


def run_ltfhplus(tbl_path, h2, tol, workers, out_path):
    rscript = shutil.which("Rscript")
    env = os.environ.copy()
    env.setdefault("OMP_NUM_THREADS", str(workers))
    proc = subprocess.run(
        [rscript, R_HELPER, tbl_path, out_path,
         str(h2), str(tol), str(workers)],
        cwd=ROOT, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(
            "LTFHPlus helper failed:\n"
            f"{proc.stdout}\n{proc.stderr}")
    return proc.stdout


def read_ltfhplus(path):
    rows = list(csv.DictReader(open(path, newline="", encoding="utf-8")))
    by_fam = {r["fam_ID"]: float(r["genetic_est"]) for r in rows}
    seconds = float(rows[0]["seconds"])
    version = rows[0]["ltfhplus_version"]
    workers = int(float(rows[0]["workers"]))
    return by_fam, seconds, version, workers


def align(families, by_fam):
    est = np.array([by_fam[str(fam.fam_id)] for fam in families], dtype=float)
    return est


def metrics(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    corr = float(np.corrcoef(a, b)[0, 1])
    rmse = float(np.sqrt(np.mean((a - b) ** 2)))
    max_abs = float(np.max(np.abs(a - b)))
    return corr, rmse, max_abs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-fam", type=int, default=N_FAM)
    parser.add_argument("--reps", type=int, default=REPS)
    parser.add_argument("--workers", type=int, default=1,
                        help="future workers for LTFHPlus (1 = sequential)")
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--output-prefix",
                        default=os.path.join(HERE, "bench_ltfhplus_compare"))
    args = parser.parse_args()

    version, err = _check_ltfhplus()
    if err:
        print(f"SKIP: LTFHPlus comparison unavailable ({err})")
        print("Install with: Rscript -e "
              "\"install.packages('LTFHPlus')\"")
        return 2

    print("Locked LTFHPlus comparison")
    print(f"LTFHPlus {version}  Rscript={shutil.which('Rscript')}")
    print(f"n_fam={args.n_fam}  reps={args.reps}  fam={'+'.join(FAM_VEC)}  "
          f"h2={H2}  K={PREV}  tol={TOL}  n_sim={N_SIM}  burn_in={BURN_IN}")
    print(f"LTFHPlus future workers={args.workers}  "
          f"Numba threads={get_num_threads()}")
    print("Estimand: posterior-mean genetic liability on classic LT-FH bounds.")
    print("LTFHPlus is Gibbs-only; PA is ltpred-only.\n")

    warm = simulate_families(FAM_VEC, H2, PREV, n_fam=8, seed=args.seed)
    estimate(warm.families, H2, "pa", tol=TOL)
    estimate(warm.families, H2, "gibbs", n_sim=N_SIM, burn_in=BURN_IN,
             tol=TOL, seed=args.seed)
    print("warmed ltpred PA and Gibbs (JIT + first factorisation)\n")

    rows = []
    with tempfile.TemporaryDirectory(prefix="ltfhplus_") as tmp:
        for rep in range(args.reps):
            sim = simulate_families(
                FAM_VEC, H2, PREV, args.n_fam, seed=args.seed + 17 * rep)
            true_g = np.asarray(sim.genetic, dtype=float)
            families = sim.families
            tbl = os.path.join(tmp, f"tbl_{rep}.csv")
            r_out = os.path.join(tmp, f"r_{rep}.csv")
            families_to_tbl(families, tbl)

            t0 = time.perf_counter()
            pa, _ = estimate(families, H2, "pa", tol=TOL)
            pa_s = time.perf_counter() - t0

            t0 = time.perf_counter()
            gibbs, _ = estimate(
                families, H2, "gibbs", n_sim=N_SIM, burn_in=BURN_IN,
                tol=TOL, seed=args.seed + 1000 + rep)
            gibbs_s = time.perf_counter() - t0

            helper_log = run_ltfhplus(
                tbl, H2, TOL, args.workers, r_out)
            print(helper_log.rstrip())
            r_by_fam, r_s, r_ver, r_workers = read_ltfhplus(r_out)
            r_est = align(families, r_by_fam)

            c_pg, rmse_pg, mx_pg = metrics(pa, gibbs)
            c_pr, rmse_pr, mx_pr = metrics(pa, r_est)
            c_gr, rmse_gr, mx_gr = metrics(gibbs, r_est)
            c_gt, _, _ = metrics(gibbs, true_g)
            c_rt, _, _ = metrics(r_est, true_g)
            c_pt, _, _ = metrics(pa, true_g)

            row = dict(
                rep=rep, n_fam=args.n_fam, h2=H2, prevalence=PREV,
                tol=TOL, n_sim=N_SIM, burn_in=BURN_IN,
                ltfhplus_version=r_ver, ltfhplus_workers=r_workers,
                numba_threads=get_num_threads(),
                seconds_ltfhplus=r_s, seconds_ltpred_gibbs=gibbs_s,
                seconds_ltpred_pa=pa_s,
                corr_pa_gibbs=c_pg, rmse_pa_gibbs=rmse_pg, maxabs_pa_gibbs=mx_pg,
                corr_pa_ltfhplus=c_pr, rmse_pa_ltfhplus=rmse_pr,
                maxabs_pa_ltfhplus=mx_pr,
                corr_gibbs_ltfhplus=c_gr, rmse_gibbs_ltfhplus=rmse_gr,
                maxabs_gibbs_ltfhplus=mx_gr,
                corr_gibbs_truth=c_gt, corr_ltfhplus_truth=c_rt,
                corr_pa_truth=c_pt,
            )
            rows.append(row)
            print(
                f"rep {rep}: corr(Gibbs,LTFHPlus)={c_gr:.5f}  "
                f"corr(PA,LTFHPlus)={c_pr:.5f}  "
                f"RMSE(Gibbs,R)={rmse_gr:.4f}  "
                f"t R={r_s:.2f}s  t Gibbs={gibbs_s:.2f}s  t PA={pa_s:.3f}s"
            )

    out_csv = f"{args.output_prefix}.csv"
    with open(out_csv, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]),
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)

    def mean_se(key):
        vals = np.array([r[key] for r in rows], float)
        se = vals.std(ddof=1) / np.sqrt(vals.size) if vals.size > 1 else np.nan
        return float(vals.mean()), float(se)

    print("\nAcross-replicate mean ± SE")
    for key, label in (
        ("corr_gibbs_ltfhplus", "corr(ltpred Gibbs, LTFHPlus)"),
        ("corr_pa_ltfhplus", "corr(ltpred PA, LTFHPlus)"),
        ("rmse_gibbs_ltfhplus", "RMSE(ltpred Gibbs, LTFHPlus)"),
        ("seconds_ltfhplus", "LTFHPlus seconds"),
        ("seconds_ltpred_gibbs", "ltpred Gibbs seconds"),
        ("seconds_ltpred_pa", "ltpred PA seconds"),
    ):
        mean, se = mean_se(key)
        print(f"  {label:36s} {mean:.4f} ± {se:.4f}")

    r_t, _ = mean_se("seconds_ltfhplus")
    g_t, _ = mean_se("seconds_ltpred_gibbs")
    p_t, _ = mean_se("seconds_ltpred_pa")
    print(f"\nWall-clock ratios on this machine "
          f"(LTFHPlus workers={args.workers}, "
          f"Numba threads={get_num_threads()}):")
    print(f"  LTFHPlus / ltpred Gibbs = {r_t / g_t:.2f}")
    print(f"  LTFHPlus / ltpred PA    = {r_t / p_t:.1f}")
    print(f"  ltpred Gibbs / ltpred PA = {g_t / p_t:.1f}")
    print("These are not hardware-independent constants.")
    print(f"\nwrote {os.path.basename(out_csv)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
